%%Mukarram Ishaq
%%111134
%%BESE-5


img=imread('tools.gif');


img=imbinarize(img);

%<-------------  Task 1  ------------>

B=[1,0,1;0,1,0;1,0,1];


eImg=imerode(img,B);

dImg=imdilate(img,B);

oImg=imopen(img,B);

cImg=imclose(img,B);

%Display processed images

figure('name','Task1');

subplot(2,2,1),
imshow(eImg,[]),
title('Erosion')

subplot(2,2,2),
imshow(dImg,[]),
title('Dilation')

subplot(2,2,3),
imshow(oImg,[]),
title('Opened Image')

subplot(2,2,4),
imshow(cImg,[]),
title('Closed Image')
%<-------------------------   END Task 1  -------------------->

%<-------------------------  Task 02    ------------------>
ocImg=imopen(img,B);
ocImg=imclose(ocImg,B);


coImg=imclose(img,B);
coImg=imopen(coImg,B);



figure('name','Task2');       %New Figure

subplot(2,1,1),
imshow(ocImg,[]),
title('Open close')

subplot(2,1,2),
imshow(coImg,[]),
title('Close open')
%<---------------------  End task 1  --------------->

%<----------------------   Task3   --------------->

figure('name','Task 3');     


chImg=imfill(img,'holes');
%Display Image
subplot(2,2,1),
imshow(chImg),
title('After Close Holes Operation');


hImg=chImg-img;

hImg=imopen(hImg,B);
%Display Image
subplot(2,2,2),
imshow(hImg),
title('Holes Image');


choImg=imopen(chImg,B);
%Display Image
subplot(2,2,3),
imshow(choImg),
title('After Open on Close Holes image');

%Subtract Holes image from Close-hole opened image.
iImg=choImg-hImg;
%Display Image
subplot(2,2,4),
imshow(iImg),
title('Open subtracted image');
%<----------------  End task 03   ---------------->

%<-----------------  Task 04  --------------->
figure('name','Task 4');       

%Reconstruct Image
rImg=imreconstruct(oImg,cImg,4);

subplot(2,1,1),
imshow(rImg,[]),
title('Directly Reconstructed Image');

subplot(2,1,2),
imshow(iImg),
title('Morphologically Reconstructed Image');


