%%%%%%%%%%%  Author %%%%%%%%%%%%%%%%%%%%%%%
%      Name: Mukarram Ishaq               %
%      CMS ID: 111134                     %
%      Class: BESE-5A                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A = imread('../images/pic1.jpg'); %read image
B = imresize(A,size(A)/2); %resize it to half of original size
figure, imshow(A), title('Original image'); %show original image
figure, imshow(B), title('Resized image')   %show resized image
imwrite(B,'../images/resized','bmp') %store image in bmp format