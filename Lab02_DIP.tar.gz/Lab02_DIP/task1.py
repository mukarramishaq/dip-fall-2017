from PIL import Image
from random import randint
image = Image.open('lab2_task2_1.jpg')
newImage = Image.new(image.mode,image.size,(255,255,255))
x,y = image.size
lastRowLabelsBucket = []
currentRowLabelsBucket = []
countLabel = -1
equalLabelList = [] #this list contains tuple of two value with first one as greater precedence
backgroundPixel = (255,255,255)
pixelBack  = (255,255,255)
pixelUp = (255,255,255)
labelUp = 0
labelBack = 0
listOfBuckets =  [] #list(labelList(bucketOfPixel(),bucketOfPixelPosition()))
#this list is of buckets of label and each label bucket has  two types of buckets one type is of pixel bucket and other type
#is of pixel position bucket relating to previous pixel bucket

def getUpLabel(pixel,pixelPosition):

    for l in range(0,len(lastRowLabelsBucket)):
        pixb = lastRowLabelsBucket[l][0]
        posb = lastRowLabelsBucket[l][1]
        lb = lastRowLabelsBucket[l][2]
        for i in range(0,len(pixb)):
            if(cmp(pixel,pixb[i]) == 0 and cmp(pixelPosition,posb[i])):
                return lb[0]
    return -1
def getBackLabel(pixel,pixelPosition):
    for l in range(0, len(currentRowLabelsBucket)):
        pixb = currentRowLabelsBucket[l][0]
        posb = currentRowLabelsBucket[l][1]
        lb = currentRowLabelsBucket[l][2]
        for i in range(0, len(pixb)):
            if (cmp(pixel, pixb[i]) == 0 and cmp(pixelPosition, posb[i])):
                return lb[0]
    return -1

    #for i in range(0,len(listOfBuckets)):
     #   pixelBucket = listOfBuckets[i][0]
      #  positionBucket = listOfBuckets[i][1]
       # for k in range (0,len(pixelBucket)):
        #    if(cmp(pixel,pixelBucket[k]) == 0 and cmp(pixelPosition,positionBucket[k]) == 0):
         #       return i
    #other wise return next label which is length of listOfBuckets
    #return len(listOfBuckets)

#phase one of classical algorithm

for i in range(0,x): #rows
    print "processing row "+str(i)+" ..."
    currentRowLabelsBucket = []
    for j in range(0,y): #columns
        pixel = image.getpixel((i,j));
        #first of all check whether it is background or not
        if(cmp(pixel,backgroundPixel) == 0):
            continue

        #check one pixel up for label
        pixelUpPosition = (i,j-1)
        pupX,pupY = pixelUpPosition
        pixelBackPosition = (i-1,j)
        pbpX,pbpY = pixelBackPosition

        #check for index out bound
        if(pupX < 0 or pupY <0):
            pixelUp = backgroundPixel
            labelUp = -1;
        else:
            pixelUp = image.getpixel(pixelUpPosition)
            labelUp = getUpLabel(pixelUp,pixelUpPosition)


        if(pbpX < 0 or pbpY < 0):
            pixelBack = backgroundPixel
            labelBack = -1;
        else:
            pixelBack = image.getpixel(pixelBackPosition);
            labelBack = getBackLabel(pixelBack,pixelBackPosition)

        if((cmp(pixel,pixelBack) == 0) and (cmp(pixelBack,backgroundPixel) != 0) and (cmp(pixel,pixelUp) == 0) and (cmp(pixelUp,backgroundPixel) != 0) ):
            if(labelBack < labelUp):
                pixelBucket = listOfBuckets[labelBack][0]
                positionBucket = listOfBuckets[labelBack][1]
                pixelBucket.append(pixel)
                positionBucket.append((i, j))
                count = len(currentRowLabelsBucket)
                # append this new label to current row label bucket
                currentRowLabelsBucket.append([[], [], []])
                currentRowLabelsBucket[count][0].append(pixel)
                currentRowLabelsBucket[count][1].append((i, j))
                currentRowLabelsBucket[count][2].append(labelBack)
            else:
                pixelBucket = listOfBuckets[labelUp][0]
                positionBucket = listOfBuckets[labelUp][1]
                pixelBucket.append(pixel)
                positionBucket.append((i, j))
                count = len(currentRowLabelsBucket)
                # append this new label to current row label bucket
                currentRowLabelsBucket.append([[], [], []])
                currentRowLabelsBucket[count][0].append(pixel)
                currentRowLabelsBucket[count][1].append((i, j))
                currentRowLabelsBucket[count][2].append(labelUp)
            equalLabelList.append((labelUp, labelBack))

        #first check upper pixel
        elif((cmp(pixel,pixelUp) == 0) and (cmp(pixelUp,backgroundPixel) != 0) and (labelUp > 0)):
            pixelBucket = listOfBuckets[labelUp][0]
            positionBucket = listOfBuckets[labelUp][1]
            pixelBucket.append(pixel)
            positionBucket.append((i,j))
            count = len(currentRowLabelsBucket)
            # append this new label to current row label bucket
            currentRowLabelsBucket.append([[], [], []])
            currentRowLabelsBucket[count][0].append(pixel)
            currentRowLabelsBucket[count][1].append((i, j))
            currentRowLabelsBucket[count][2].append(labelUp)
            #check for equavalence
            #if((cmp(pixelBack,backgroundPixel) != 0) and (labelBack != labelUp) and (labelUp > 0) and (labelBack > -1)):
             #   equalLabelList.append((labelUp,labelBack))

         #then check one back pixel
        elif((cmp(pixel,pixelBack) == 0) and (cmp(pixelBack,backgroundPixel) != 0) and (labelBack > 0)):
            pixelBucket = listOfBuckets[labelBack][0]
            positionBucket = listOfBuckets[labelBack][1]
            pixelBucket.append(pixel)
            positionBucket.append((i, j))
            count = len(currentRowLabelsBucket)
            # append this new label to current row label bucket
            currentRowLabelsBucket.append([[], [], []])
            currentRowLabelsBucket[count][0].append(pixel)
            currentRowLabelsBucket[count][1].append((i, j))
            currentRowLabelsBucket[count][2].append(labelBack)
            # check for equavalence
            #if ((cmp(pixelUp, backgroundPixel) != 0) and (labelUp != labelBack) and (labelBack > 0) and (labelUp > -1)):
             #   equalLabelList.append((labelBack, labelUp))

        # otherwise its a new label pixel
        else:
            countLabel = countLabel + 1
            newLabel = countLabel

            #create new label bucket in listOfBucket
            listOfBuckets.append([[],[]])
            labelBucket = listOfBuckets[newLabel];

            pixelBucket = labelBucket[0]
            positionBucket = labelBucket[1]
            pixelBucket.append(pixel)
            positionBucket.append((i,j))

            count = len(currentRowLabelsBucket)
            #append this new label to current row label bucket
            currentRowLabelsBucket.append([[],[],[]])
            currentRowLabelsBucket[count][0].append(pixel)
            currentRowLabelsBucket[count][1].append((i,j))
            currentRowLabelsBucket[count][2].append(newLabel)
    print "processed"
    lastRowLabelsBucket = currentRowLabelsBucket


#phase two of classical algorithm
def syncronizeLabels(lob,ell):
    print "synchronizing the labels (total "+str(len(ell))+")..."
    for i  in range(len(ell)-1,0,-1):
        print "processing ell["+str(i)+"]: "
        print ell[i]
        labelTuple = ell[i]
        #check for smallnes of label then do ...
        if(labelTuple[0] < labelTuple[1]):
            try:
                dominatedLabelBucket = lob.pop(labelTuple[1])
                #merge poppedLabelBucket with that of labelTuple[0]
                dominantLabelBucket = lob[labelTuple[0]]
                dominantLabelBucket[0] = dominantLabelBucket[0] + dominatedLabelBucket[0]
                dominantLabelBucket[1] = dominantLabelBucket[1] + dominatedLabelBucket[1]
            except Exception:
                continue
        else:
            try:
                dominatedLabelBucket = lob.pop(labelTuple[0])
                # merge poppedLabelBucket with that of labelTuple[0]
                dominantLabelBucket = lob[labelTuple[1]]
                dominantLabelBucket[0] = dominantLabelBucket[0] + dominatedLabelBucket[0]
                dominantLabelBucket[1] = dominantLabelBucket[1] + dominatedLabelBucket[1]
            except Exception:
                continue
    print "labels synched"
    return
def changeColorOfEveryComponentAndReturnImage(lob,newImage):
    print "changing colors of connected components..."
    print "Size of lob:"+str(len(lob))
    colorList = [(0,0,0),(255,255,255),(255,0,0),(0,255,0),(0,0,255),(255,255,0),(0,255,255),(255,0,255),(192,192,192),(128,128,128),(128,0,0),(128,128,0),(0,128,0),(128,0,128),(0,128,128),(0,0,128)]
    print len(listOfBuckets)
    clc = 0;
    ccc = 0;
    for eachBucket in lob:
        sepImg = Image.new(newImage.mode,newImage.size,(255,255,255))

        newPixel = colorList[(clc%len(colorList))]
        for i in  range(0,len(eachBucket[0])):
            eachBucket[0][i] = newPixel
            newImage.putpixel((eachBucket[1][i]),newPixel)
            sepImg.putpixel((eachBucket[1][i]),newPixel)
        clc = clc + 1;

        ccc = ccc+1
    print "colors changed of connected components"
    return newImage

def filterBucketList(lob):
    for eachBucket in lob:
        if(len(eachBucket[0]) < 100):
            eachBucket = []

def showUniquePixels():
	im = Image.open('lab2_task2_1.jpg').convert('1');
	
	ul = []
	for xx in range(0,x):
		for yy in range(0,y):
			if im.getpixel((xx,yy)) not in ul:
				ul += [im.getpixel((xx,yy))]
				print im.getpixel((xx,yy))
				#if(im2.getpixel((xx,yy)) > (150,150,150)):
					#im.putpixel((xx,yy),(255,255,255))
				#else:
					#im.putpixel((xx,yy),(0,0,0))
	im.save('unn.png');
					
	print len(ul)
			


syncronizeLabels(listOfBuckets,equalLabelList)

filterBucketList(listOfBuckets)
nimg = changeColorOfEveryComponentAndReturnImage(listOfBuckets,newImage)
print "Saving processed image to disk..."
nimg.save('processed.jpg')
print "Processed image saved"


#print listOfBuckets


